ECM1410 Pair Programming Coursework

Please complete this coverpage and include in your submission:

Student 1 Candidate number: 028880

Student 2 Candidate number: 026182

Please write below a short statement detailing how you used GenAI tools to assist in your submission:


