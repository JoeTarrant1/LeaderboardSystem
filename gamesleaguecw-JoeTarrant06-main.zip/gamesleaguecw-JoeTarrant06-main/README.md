[![Open in Codespaces](https://classroom.github.com/assets/launch-codespace-2972f46106e565e64193e422d61a12cf1da4916b45550586e14ef0a7c637dd04.svg)](https://classroom.github.com/open-in-codespaces?assignment_repo_id=18519189)
# ECM1410-2025T2-PairProgrammingCoursework

Please see the coursework specification:

https://github.com/My-UofE/ECM1410-2025T2-PairProgrammingCoursework/tree/main

The templates folder contains a skeleton `GamesLeague.java` class file that has been set up with placeholder methods to implement the specified interface in `GamesLeagueInterface.java`. 

You may copy this file to the `src/gamesleague` folder to save you manually creating it.

e.g. using:

```
cp ./templates/GamesLeague.java src/GamesLeague.java
```
